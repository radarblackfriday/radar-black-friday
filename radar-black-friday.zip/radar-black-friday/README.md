# Radar Black Friday

Página de ofertas com seus links de afiliado. A lista de produtos vem de dois lugares:

- `manual.json`: produtos que você escolhe à mão.
- API de afiliados (hoje só a Shopee): o script `scripts/update_products.py` busca produtos com bom desconto e boa avaliação.

O GitHub roda o script sozinho a cada poucas horas e atualiza o `products.json`, que a página lê.

## Arquivos

| Arquivo | Função |
| --- | --- |
| `index.html` | A página que o público vê |
| `manual.json` | Seus produtos escolhidos à mão (comece por aqui) |
| `products.json` | Lista final, gerada pelo script. Não edite à mão |
| `scripts/update_products.py` | Junta manual + API e gera o `products.json` |
| `.github/workflows/update.yml` | Agenda o script no GitHub Actions |

## Passo a passo no GitHub

1. Crie uma conta em github.com (se ainda não tiver).
2. Clique em **New repository**. Nome: `radar-black-friday`. Marque **Public**. Crie.
3. No repositório, clique em **Add file > Upload files** e envie os arquivos mantendo as pastas (`scripts/` e `.github/workflows/`). Se o envio não aceitar pastas, use **Add file > Create new file**, digite o caminho completo no nome (ex.: `scripts/update_products.py`) e cole o conteúdo. Clique em **Commit changes**.
4. Ative a página pública: **Settings > Pages**. Em **Build and deployment**, escolha **Deploy from a branch**, branch `main`, pasta `/ (root)`, e salve. Em 1 a 3 minutos o endereço aparece no topo: `https://SEU-USUARIO.github.io/radar-black-friday/`.
5. Dê permissão para o agendamento salvar a lista: **Settings > Actions > General > Workflow permissions**, marque **Read and write permissions** e salve.
6. (Só para a API da Shopee) Cadastre as chaves: **Settings > Secrets and variables > Actions > New repository secret**. Crie dois segredos:
   - `SHOPEE_APP_ID`
   - `SHOPEE_SECRET`
   Pegue esses dados no painel de afiliados da Shopee (procure pela API de afiliados / Open API). Nunca escreva essas chaves em arquivo nem mande em chat.
7. Teste: aba **Actions > Atualizar produtos > Run workflow**. Abra a execução e leia o log. Se aparecer erro da Shopee, copie a mensagem e peça ajuda para ajustar.

## Como colocar seus produtos (lista manual)

Edite o `manual.json` direto no GitHub (ícone de lápis). Cada produto tem:

```json
{ "nome": "Fone Bluetooth X", "loja": "Shopee", "cat": "Eletrônicos",
  "preco": 89.9, "antes": 159.9, "visto": "13/11",
  "link": "SEU_LINK_DE_AFILIADO", "imagem": "", "exemplo": false }
```

- `preco` e `antes` são números com ponto, sem R$.
- `visto` é a data em que você conferiu o preço.
- `link` é o seu link de afiliado. Sem link, o botão fica desativado.
- `imagem` é opcional (endereço da foto do produto).
- Troque `exemplo` para `false` (ou apague a linha). Os 12 produtos que vêm no arquivo são exemplos inventados e devem ser removidos.

Depois de salvar, rode o **Run workflow** para atualizar a página na hora.

## Ajustes do filtro automático

No `update.yml` ou nas variáveis do GitHub você pode trocar: `MIN_DESCONTO` (padrão 30), `MIN_AVALIACAO` (4.5), `MAX_AUTO` (30) e `SHOPEE_PALAVRAS` (palavras de busca separadas por vírgula).

## Avisos importantes

- A integração com a Shopee foi escrita sem teste com chaves reais. Pode precisar de ajuste.
- Mercado Livre, Amazon, AliExpress e Magalu ainda não estão automatizados. Use o `manual.json` para eles.
- O desconto automático é calculado a partir do percentual informado pela loja e pode não refletir o histórico real do preço. Confira os produtos antes de divulgar.
- Mantenha o aviso de link de afiliado no rodapé e confira as regras de cada programa de afiliados.
- O agendamento do GitHub pode atrasar alguns minutos, e em repositório sem atividade por 60 dias ele é desativado. Se isso acontecer, reative na aba Actions.
- Na Black Friday, troque o cron do `update.yml` para `"0 * * * *"` (toda hora).
