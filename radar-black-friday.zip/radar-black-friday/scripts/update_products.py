#!/usr/bin/env python3
"""Monta o products.json da página a partir de duas fontes:

1. manual.json: produtos que você escolhe à mão, com seus links de afiliado.
2. APIs de afiliados (hoje só a Shopee). Se as chaves não estiverem
   configuradas ou a API falhar, o script segue só com a lista manual e a
   página continua funcionando.

Usa apenas a biblioteca padrão do Python. Não precisa instalar nada.

ATENÇÃO: a parte da Shopee foi escrita a partir da documentação da API de
afiliados que eu conheço e NÃO foi testada com chaves reais. Se der erro,
leia a mensagem impressa no log do GitHub Actions e ajuste os nomes dos
campos na função buscar_shopee(). Confira também a documentação atual no
painel de afiliados da Shopee.
"""
import hashlib
import json
import os
import sys
import time
import urllib.request
from datetime import datetime, timedelta, timezone

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ARQ_MANUAL = os.path.join(RAIZ, "manual.json")
ARQ_SAIDA = os.path.join(RAIZ, "products.json")
FUSO_BR = timezone(timedelta(hours=-3))

# Ajustes (podem ser trocados por variáveis no GitHub sem mexer no código).
MIN_DESCONTO = int(os.environ.get("MIN_DESCONTO", "30"))       # em %
MIN_AVALIACAO = float(os.environ.get("MIN_AVALIACAO", "4.5"))  # estrelas
MAX_AUTO = int(os.environ.get("MAX_AUTO", "30"))               # máx. de itens automáticos
PALAVRAS_SHOPEE = [
    p.strip()
    for p in os.environ.get(
        "SHOPEE_PALAVRAS",
        "fone bluetooth,fritadeira,organizador cozinha,skincare,mochila",
    ).split(",")
    if p.strip()
]

SHOPEE_URL = "https://open-api.affiliate.shopee.com.br/graphql"


def agora_br():
    return datetime.now(FUSO_BR)


def carregar_manual():
    if not os.path.exists(ARQ_MANUAL):
        return []
    with open(ARQ_MANUAL, encoding="utf-8") as f:
        dados = json.load(f)
    validos = []
    for p in dados:
        if all(k in p for k in ("nome", "loja", "cat", "preco")):
            validos.append(p)
        else:
            print("Item do manual.json ignorado (faltam campos):", p, file=sys.stderr)
    return validos


def assinar_shopee(app_id, segredo, payload, ts):
    base = f"{app_id}{ts}{payload}{segredo}"
    return hashlib.sha256(base.encode("utf-8")).hexdigest()


def montar_consulta_shopee(palavra, limite=20):
    return (
        "query { productOfferV2("
        f"keyword: {json.dumps(palavra)}, sortType: 2, page: 1, limit: {int(limite)}"
        ") { nodes { itemId productName priceMin priceMax priceDiscountRate "
        "ratingStar sales imageUrl shopName offerLink } } }"
    )


def shopee_para_produto(n):
    """Converte um item da API da Shopee no formato da página. Devolve None se não servir."""
    try:
        preco = float(n.get("priceMin") or n.get("priceMax") or 0)
        taxa = float(n.get("priceDiscountRate") or 0)  # esperado em %, ex.: 35
        nota = float(n.get("ratingStar") or 0)
    except (TypeError, ValueError):
        return None
    link = n.get("offerLink") or ""
    if preco <= 0 or not link:
        return None
    if taxa < MIN_DESCONTO or (nota and nota < MIN_AVALIACAO):
        return None
    antes = round(preco / (1 - taxa / 100), 2) if 0 < taxa < 95 else 0
    return {
        "nome": (n.get("productName") or "").strip(),
        "loja": "Shopee",
        "cat": "Variados",
        "preco": round(preco, 2),
        "antes": antes,
        "visto": agora_br().strftime("%d/%m"),
        "link": link,
        "imagem": n.get("imageUrl") or "",
        "vendas": int(n.get("sales") or 0),
        "exemplo": False,
    }


def buscar_shopee():
    app_id = os.environ.get("SHOPEE_APP_ID", "").strip()
    segredo = os.environ.get("SHOPEE_SECRET", "").strip()
    if not app_id or not segredo:
        print("Shopee: chaves não configuradas, pulando.")
        return []
    achados = {}
    for palavra in PALAVRAS_SHOPEE:
        payload = json.dumps({"query": montar_consulta_shopee(palavra)}, separators=(",", ":"))
        ts = str(int(time.time()))
        assinatura = assinar_shopee(app_id, segredo, payload, ts)
        req = urllib.request.Request(
            SHOPEE_URL,
            data=payload.encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"SHA256 Credential={app_id}, Timestamp={ts}, Signature={assinatura}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                resposta = json.loads(r.read().decode("utf-8"))
        except Exception as e:  # rede, HTTP, JSON inválido
            print(f"Shopee ({palavra}): erro na chamada: {e}", file=sys.stderr)
            continue
        if resposta.get("errors"):
            print(f"Shopee ({palavra}): a API devolveu erro: {resposta['errors']}", file=sys.stderr)
            continue
        nos = ((resposta.get("data") or {}).get("productOfferV2") or {}).get("nodes") or []
        for n in nos:
            item = shopee_para_produto(n)
            if item and n.get("itemId") not in achados:
                achados[n.get("itemId")] = item
    lista = sorted(achados.values(), key=lambda p: p.get("vendas", 0), reverse=True)
    print(f"Shopee: {len(lista)} produtos dentro dos filtros.")
    return lista[:MAX_AUTO]


# Mercado Livre, Amazon, AliExpress e Magalu: implemente aqui quando você
# tiver acesso à API oficial de afiliados de cada loja. Cada função deve
# devolver uma lista de dicionários no mesmo formato de shopee_para_produto().
def buscar_mercadolivre():
    return []


def buscar_amazon():
    return []


def buscar_aliexpress():
    return []


def buscar_magalu():
    return []


FONTES = [buscar_shopee, buscar_mercadolivre, buscar_amazon, buscar_aliexpress, buscar_magalu]


def juntar(manual, automaticos):
    vistos, saida = set(), []
    for p in list(manual) + list(automaticos):
        chave = p.get("link") or (p["loja"], p["nome"])
        if chave in vistos:
            continue
        vistos.add(chave)
        saida.append(p)
    return saida


def main():
    manual = carregar_manual()
    automaticos = []
    for fonte in FONTES:
        try:
            automaticos.extend(fonte())
        except Exception as e:
            print(f"{fonte.__name__}: falhou: {e}", file=sys.stderr)
    produtos = juntar(manual, automaticos)

    antigo = None
    if os.path.exists(ARQ_SAIDA):
        try:
            with open(ARQ_SAIDA, encoding="utf-8") as f:
                antigo = json.load(f)
        except Exception:
            antigo = None
    if antigo and antigo.get("produtos") == produtos:
        print("Nada mudou. products.json mantido.")
        return
    saida = {"atualizado_em": agora_br().strftime("%d/%m/%Y %H:%M"), "produtos": produtos}
    with open(ARQ_SAIDA, "w", encoding="utf-8") as f:
        json.dump(saida, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(f"products.json atualizado com {len(produtos)} produtos.")


if __name__ == "__main__":
    main()
